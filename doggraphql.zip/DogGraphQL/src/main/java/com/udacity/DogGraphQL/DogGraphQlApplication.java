package com.udacity.DogGraphQL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DogGraphQlApplication {

	public static void main(String[] args) {
		SpringApplication.run(DogGraphQlApplication.class, args);
	}

}
