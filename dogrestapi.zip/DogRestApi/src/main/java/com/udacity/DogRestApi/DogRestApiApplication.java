package com.udacity.DogRestApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DogRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DogRestApiApplication.class, args);
	}

}
